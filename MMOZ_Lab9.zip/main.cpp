#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/core/utility.hpp>
#include <iostream>

using namespace cv;

const Point pointShift[8] =
    {
        Point(-1, -1), Point(0, -1),
        Point(1, -1), Point(1, 0),
        Point(1, 1), Point(0, 1),
        Point(-1, 1), Point(-1, 0),
    };



void binarize(Mat& img, int threshold) {
    for (int i = 0; i < img.rows; ++i) {
        uchar* rowPtr = img.ptr<uchar>(i);
        for (int j = 0; j < img.cols; ++j) {
            rowPtr[j] = (rowPtr[j] < threshold) ? 0 : 255;
        }
    }
}

std::vector<Point> boundaryTracing(Mat& img, Mat& out) {
    int startX = -1, startY = -1;

    for (int i = 0; i < img.rows; ++i) {
        if (startX != -1 || startY != -1)
            break;
        uchar* rowPtr = img.ptr<uchar>(i);
        for (int j = 0; j < img.cols; ++j) {
            if (rowPtr[j] == 255) {
                startY = i;
                startX = j;
                break;
            }
        }
    }

    std::vector<Point> contour;
    Point shifted, current, prev;
    current = Point(startX, startY);
    out.ptr<uchar>(current.y)[current.x] = 255;
    prev = Point(startX - 1, startY);
    int i;
    do {
        contour.push_back(current);
        i = 0;
        while (shifted != prev) {
            shifted = current + pointShift[i];
            i = (i + 1) % 8;
        }

        for (int j = 0; j < 8; ++j) {
            shifted = current + pointShift[(i + j) % 8];
            uchar pixelValue = img.ptr<uchar>(shifted.y)[shifted.x];
            if (pixelValue == 255) {
                out.ptr<uchar>(shifted.y)[shifted.x] = 255;
                prev = current + pointShift[(i + j + 7) % 8];
                current = shifted;
                break;
            }
        }
    } while (current.y != startY || current.x != startX);
    return contour;
}

void contourCurve(Mat& img, int k = 1) {
    Mat boundary = Mat::zeros(img.rows, img.cols, img.type());
    std::vector<Point> contour = boundaryTracing(img, boundary);
    int contourSize = contour.size();
    Point prev, current, next, fv, bv;
    double d_b, d_f, deg_f, deg_b, deg_avg, diff_f;
    imshow("Original", img);
    imshow("Contour", boundary);

    std::vector<double> result;

    for (int i = k; i < contourSize - k; ++i) {
        prev = contour[i - k];
        current = contour[i];
        next = contour[i + k];
        fv = Point(current.x - next.x, current.y - next.y);
        bv = Point(current.x - prev.x, current.y - prev.y);

        d_f = sqrt(fv.x * fv.x + fv.y * fv.y);
        d_b = sqrt(bv.x * bv.x + bv.y * bv.y);
        deg_f = atan2(abs(fv.x), abs(fv.y));
        deg_b = atan2(abs(bv.x), abs(bv.y));
        deg_avg = (deg_f + deg_b) / 2;
        diff_f = deg_f - deg_avg;
        result.push_back(diff_f * (d_b + d_f) / (2 * d_b * d_f));
    }
    int hist_h = 512;
    int hist_w = result.size();
}

int main() {
  //  Mat img = imread("C:/DEV/MMOZ_Lab9/circle.png", IMREAD_GRAYSCALE);
 Mat img = imread("C:/DEV/MMOZ_Lab9/contour.tif", IMREAD_GRAYSCALE);


    Mat binarized(img.clone());

    binarize(binarized, 125);


    contourCurve(binarized);

    waitKey(0);
    return 0;
}
